module jmp.bank.api {
    requires jmp.dto;

    exports com.epam.jmp.service;
}