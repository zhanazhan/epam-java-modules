package com.epam.jmp.dto;

public enum BankCardType {
    CREDIT,
    DEBIT
}
