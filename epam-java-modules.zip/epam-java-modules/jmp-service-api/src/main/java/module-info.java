module jmp.service.api {
    requires jmp.dto;

    exports com.epam.jmp.service;
}
